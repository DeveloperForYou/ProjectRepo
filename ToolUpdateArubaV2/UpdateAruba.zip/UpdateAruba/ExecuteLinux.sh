while true; 
do
 java -jar  java -jar DirectoryDoveAveteEstrattoArchivioZippato/UpdateAruba/dist/UpdateAruba.jar
 pkill chrome
done 
