while true; 
do
 java -jar DirectoryDoveAveteEstrattoArchivioZippato/UpdateAruba/dist/UpdateAruba.jar
 pkill chrome
done 
