while($true)
{
 java -jar DirectoryDoveAveteEstrattoArchivioZippato/UpdateAruba/dist/UpdateAruba.jar
 taskkill /IM chrome.exe /F
}