while($true)
{
 java -jar /home/alberto/Scrivania/UpdateAruba/dist/UpdateAruba.jar
 taskkill /IM chrome.exe /F
}
  

