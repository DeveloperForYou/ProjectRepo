while true; 
do
 /usr/lib/jvm/java-13-openjdk-amd64/bin/java -jar /home/alberto/Scrivania/UpdateAruba/dist/UpdateAruba.jar
 pkill chrome
done 
